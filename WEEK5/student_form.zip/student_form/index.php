<?php
session_start();

$errors = [];   
$old    = [];   

$textFields = [
    'name'         => 'Full name',
    'pob'          => 'Place of birth',
    'dob'          => 'Date of birth',
    'address'      => 'Address',
    'gender'       => 'Gender',
    'phone'        => 'Telephone',
    'email'        => 'Email',
    'parent_name'  => 'Parent name',
    'parent_phone' => 'Parent telephone',
    'relationship' => 'Relationship',
    'student_id'   => 'Student ID',
    'faculty'      => 'Faculty',
    'department'   => 'Department',
    'class'        => 'Class',
    'reg_date'     => 'Registration date',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    
    foreach ($textFields as $field => $label) {
        $old[$field] = isset($_POST[$field]) ? trim($_POST[$field]) : '';
        if ($old[$field] === '') {
            $errors[$field] = "Please enter your $label.";
        }
    }

    
    if (!isset($errors['name']) && !preg_match("/^[A-Za-z ]+$/", $old['name'])) {
        $errors['name'] = "Name can only contain letters and spaces.";
    }

   
    if (!isset($errors['email']) && !filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Please enter a valid email address (example: name@mail.com).";
    }

   
    $newImageName = '';
    $allowed = ['png', 'jpg', 'jpeg', 'gif'];

    if (!isset($_FILES['image']) || $_FILES['image']['error'] === UPLOAD_ERR_NO_FILE) {
        $errors['image'] = "Please upload an image.";
    } elseif ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        $errors['image'] = "There was a problem uploading the image. Try again.";
    } else {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed)) {
            $errors['image'] = "Only PNG, JPG, JPEG and GIF files are allowed.";
        } elseif (getimagesize($_FILES['image']['tmp_name']) === false) {
            $errors['image'] = "The selected file is not a real image.";
        }
    }

    
    if (empty($errors)) {
        $newImageName = uniqid('student_') . '.' . $ext;
        move_uploaded_file($_FILES['image']['tmp_name'], 'uploads/' . $newImageName);

        $old['image'] = $newImageName;
        $_SESSION['student'] = $old;

        header("Location: result.php");
        exit;
    }
}


function val($key) {
    global $old;
    return isset($old[$key]) ? htmlspecialchars($old[$key]) : '';
}
function cls($key) {
    global $errors;
    return isset($errors[$key]) ? 'form-control is-invalid' : 'form-control';
}
function err($key) {
    global $errors;
    if (isset($errors[$key])) {
        echo '<div class="text-danger small mt-1">' . htmlspecialchars($errors[$key]) . '</div>';
    }
}


$firstError = !empty($errors) ? array_key_first($errors) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student Registration Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-4">
    <div class="col-lg-8 mx-auto">

        <h2 class="text-center mb-4">Student Registration Form</h2>

        <?php if (!empty($errors)) { ?>
            <div class="alert alert-danger">
                Please fix the <?php echo count($errors); ?> error(s) shown below.
            </div>
        <?php } ?>

        <form method="post" action="index.php" enctype="multipart/form-data" novalidate>

            <!-- PERSONAL INFORMATION -->
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white">Personal Information</div>
                <div class="card-body">
                    <div class="row g-3">

                        <div class="col-md-6">
                            <label class="form-label" for="name">Full Name</label>
                            <input type="text" id="name" name="name" class="<?php echo cls('name'); ?>" value="<?php echo val('name'); ?>">
                            <?php err('name'); ?>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label" for="pob">Place of Birth</label>
                            <input type="text" id="pob" name="pob" class="<?php echo cls('pob'); ?>" value="<?php echo val('pob'); ?>">
                            <?php err('pob'); ?>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label" for="dob">Date of Birth</label>
                            <input type="date" id="dob" name="dob" class="<?php echo cls('dob'); ?>" value="<?php echo val('dob'); ?>">
                            <?php err('dob'); ?>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label" for="address">Address</label>
                            <input type="text" id="address" name="address" class="<?php echo cls('address'); ?>" value="<?php echo val('address'); ?>">
                            <?php err('address'); ?>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label d-block">Gender</label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender" id="gender" value="Male" <?php if (val('gender') == 'Male') echo 'checked'; ?>>
                                <label class="form-check-label" for="gender">Male</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender" id="gender_female" value="Female" <?php if (val('gender') == 'Female') echo 'checked'; ?>>
                                <label class="form-check-label" for="gender_female">Female</label>
                            </div>
                            <?php err('gender'); ?>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label" for="phone">Telephone</label>
                            <input type="text" id="phone" name="phone" class="<?php echo cls('phone'); ?>" value="<?php echo val('phone'); ?>">
                            <?php err('phone'); ?>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label" for="email">Email</label>
                            <input type="text" id="email" name="email" class="<?php echo cls('email'); ?>" value="<?php echo val('email'); ?>">
                            <?php err('email'); ?>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label" for="image">Image</label>
                            <input type="file" id="image" name="image" class="<?php echo cls('image'); ?>" accept=".png,.jpg,.jpeg,.gif">
                            <?php err('image'); ?>
                        </div>

                    </div>
                </div>
            </div>

            <!-- PARENT INFORMATION -->
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-success text-white">Parent Information</div>
                <div class="card-body">
                    <div class="row g-3">

                        <div class="col-md-4">
                            <label class="form-label" for="parent_name">Parent Name</label>
                            <input type="text" id="parent_name" name="parent_name" class="<?php echo cls('parent_name'); ?>" value="<?php echo val('parent_name'); ?>">
                            <?php err('parent_name'); ?>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label" for="parent_phone">Parent Telephone</label>
                            <input type="text" id="parent_phone" name="parent_phone" class="<?php echo cls('parent_phone'); ?>" value="<?php echo val('parent_phone'); ?>">
                            <?php err('parent_phone'); ?>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label" for="relationship">Relationship</label>
                            <select id="relationship" name="relationship" class="<?php echo cls('relationship'); ?>">
                                <option value="">-- Select --</option>
                                <?php
                                $options = ['Father', 'Mother', 'Brother', 'Sister', 'Uncle', 'Aunt', 'Guardian'];
                                foreach ($options as $o) {
                                    $sel = (val('relationship') == $o) ? 'selected' : '';
                                    echo "<option value=\"$o\" $sel>$o</option>";
                                }
                                ?>
                            </select>
                            <?php err('relationship'); ?>
                        </div>

                    </div>
                </div>
            </div>

            <!-- ACADEMIC INFORMATION -->
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-dark text-white">Academic Information</div>
                <div class="card-body">
                    <div class="row g-3">

                        <div class="col-md-6">
                            <label class="form-label" for="student_id">Student ID</label>
                            <input type="text" id="student_id" name="student_id" class="<?php echo cls('student_id'); ?>" value="<?php echo val('student_id'); ?>">
                            <?php err('student_id'); ?>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label" for="faculty">Faculty</label>
                            <input type="text" id="faculty" name="faculty" class="<?php echo cls('faculty'); ?>" value="<?php echo val('faculty'); ?>">
                            <?php err('faculty'); ?>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label" for="department">Department</label>
                            <input type="text" id="department" name="department" class="<?php echo cls('department'); ?>" value="<?php echo val('department'); ?>">
                            <?php err('department'); ?>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label" for="class">Class</label>
                            <input type="text" id="class" name="class" class="<?php echo cls('class'); ?>" value="<?php echo val('class'); ?>">
                            <?php err('class'); ?>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label" for="reg_date">Registration Date</label>
                            <input type="date" id="reg_date" name="reg_date" class="<?php echo cls('reg_date'); ?>" value="<?php echo val('reg_date'); ?>">
                            <?php err('reg_date'); ?>
                        </div>

                    </div>
                </div>
            </div>

            <div class="d-grid">
                <button type="submit" class="btn btn-primary btn-lg">Register</button>
            </div>

        </form>
    </div>
</div>

<?php if ($firstError != '') { ?>
<script>
   
    var field = document.getElementById("<?php echo $firstError; ?>");
    if (field) {
        field.scrollIntoView({ behavior: "smooth", block: "center" });
        field.focus();
    }
</script>
<?php } ?>

</body>
</html>

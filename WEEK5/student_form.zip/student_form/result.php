<?php
session_start();

// If someone opens this page directly, send them back to the form
if (!isset($_SESSION['student'])) {
    header("Location: index.php");
    exit;
}

$s = $_SESSION['student'];

function show($value) {
    return htmlspecialchars($value);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration Result</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-4">
    <div class="col-lg-8 mx-auto">

        <div class="alert alert-success text-center">
            <h4 class="mb-0">Registration Successful!</h4>
        </div>

        <div class="text-center mb-4">
            <img src="uploads/<?php echo show($s['image']); ?>" alt="Student Image"
                 class="img-thumbnail" style="width: 160px; height: 160px; object-fit: cover;">
        </div>

        <!-- Personal Information -->
        <table class="table table-bordered table-striped bg-white shadow-sm">
            <thead class="table-primary">
                <tr><th colspan="2">Personal Information</th></tr>
            </thead>
            <tbody>
                <tr><th width="35%">Full Name</th><td><?php echo show($s['name']); ?></td></tr>
                <tr><th>Place of Birth</th><td><?php echo show($s['pob']); ?></td></tr>
                <tr><th>Date of Birth</th><td><?php echo show($s['dob']); ?></td></tr>
                <tr><th>Address</th><td><?php echo show($s['address']); ?></td></tr>
                <tr><th>Gender</th><td><?php echo show($s['gender']); ?></td></tr>
                <tr><th>Telephone</th><td><?php echo show($s['phone']); ?></td></tr>
                <tr><th>Email</th><td><?php echo show($s['email']); ?></td></tr>
            </tbody>
        </table>

        <!-- Parent Information -->
        <table class="table table-bordered table-striped bg-white shadow-sm">
            <thead class="table-success">
                <tr><th colspan="2">Parent Information</th></tr>
            </thead>
            <tbody>
                <tr><th width="35%">Parent Name</th><td><?php echo show($s['parent_name']); ?></td></tr>
                <tr><th>Parent Telephone</th><td><?php echo show($s['parent_phone']); ?></td></tr>
                <tr><th>Relationship</th><td><?php echo show($s['relationship']); ?></td></tr>
            </tbody>
        </table>

        <!-- Academic Information -->
        <table class="table table-bordered table-striped bg-white shadow-sm">
            <thead class="table-dark">
                <tr><th colspan="2">Academic Information</th></tr>
            </thead>
            <tbody>
                <tr><th width="35%">Student ID</th><td><?php echo show($s['student_id']); ?></td></tr>
                <tr><th>Faculty</th><td><?php echo show($s['faculty']); ?></td></tr>
                <tr><th>Department</th><td><?php echo show($s['department']); ?></td></tr>
                <tr><th>Class</th><td><?php echo show($s['class']); ?></td></tr>
                <tr><th>Registration Date</th><td><?php echo show($s['reg_date']); ?></td></tr>
            </tbody>
        </table>

        <div class="text-center">
            <a href="index.php" class="btn btn-primary">Register Another Student</a>
        </div>

    </div>
</div>

</body>
</html>
